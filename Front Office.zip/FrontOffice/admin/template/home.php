 <!--sidebar end-->

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <div class="row-mt">
      <section id="main-content">
      <section class="wrapper">
          <div class="col-md-4 col-sm-4 mb">
            <div class="row mt" style="width: 750px;">

                        <!--CUSTOM CHART START -->
                        <div class="border-head">
                            <h3>VISITS</h3>
                        </div>
                        <div class="custom-bar-chart">
                            <ul class="y-axis">
                                <li><span>10.000</span></li>
                                <li><span>8.000</span></li>
                                <li><span>6.000</span></li>
                                <li><span>4.000</span></li>
                                <li><span>2.000</span></li>
                                <li><span>0</span></li>
                            </ul>
                            <div class="bar">
                                <div class="title">JAN</div>
                                <div style="height: 0px;" class="value tooltips" data-original-title="8.500" data-toggle="tooltip" data-placement="top"></div>
                            </div>
                            <div class="bar ">
                                <div class="title">FEB</div>
                                <div style="height: 0px;" class="value tooltips" data-original-title="5.000" data-toggle="tooltip" data-placement="top"></div>
                            </div>
                            <div class="bar ">
                                <div class="title">MAR</div>
                                <div style="height: 0px;" class="value tooltips" data-original-title="6.000" data-toggle="tooltip" data-placement="top"></div>
                            </div>
                            <div class="bar ">
                                <div class="title">APR</div>
                                <div style="height: 0px;" class="value tooltips" data-original-title="4.500" data-toggle="tooltip" data-placement="top"></div>
                            </div>
                            <div class="bar">
                                <div class="title">MAY</div>
                                <div style="height: 0px;" class="value tooltips" data-original-title="3.200" data-toggle="tooltip" data-placement="top"></div>
                            </div>
                            <div class="bar ">
                                <div class="title">JUN</div>
                                <div style="height: 0px;" class="value tooltips" data-original-title="6.200" data-toggle="tooltip" data-placement="top"></div>
                            </div>
                            <div class="bar">
                                <div class="title">JUL</div>
                                <div style="height: 0px;" class="value tooltips" data-original-title="7.500" data-toggle="tooltip" data-placement="top"></div>
                            </div>
                        </div>
                        <!--custom chart end-->
  					</div>
            
		  </div><! --/row -->
	  </section>
  </section>
